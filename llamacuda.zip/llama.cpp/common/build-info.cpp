int LLAMA_BUILD_NUMBER = 1728;
char const *LLAMA_COMMIT = "a20f3c7";
char const *LLAMA_COMPILER = "cc (Ubuntu 13.2.0-4ubuntu3) 13.2.0";
char const *LLAMA_BUILD_TARGET = "x86_64-linux-gnu";
